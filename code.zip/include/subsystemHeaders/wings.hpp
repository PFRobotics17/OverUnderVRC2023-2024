#include "main.h"

//helper function

void setWings(int wing);

//sets the buttons and maeks it function
void setWingButtons();