#include "main.h"

//hpp is for function headers, cpp is for source code
//make these global

//helper function
void setDrive(int left, int right);

//driver stf

void setDriveMotors();