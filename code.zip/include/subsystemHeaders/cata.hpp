#include "main.h"

//helper function

void setCata(int move);

//sets the buttons and maeks it function
void setCataButtons();