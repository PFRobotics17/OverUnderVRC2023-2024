#include "main.h"

//hpp is for function headers, cpp is for source code
//make these global

//helper function
void setIntake(int spin, int out);

//setting motors

void setIntakeButtons();

//lift

void setLiftButtons();